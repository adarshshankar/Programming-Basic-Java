package com.manish.javadev.collection;

import java.util.HashMap;
import java.util.Map;

public class HashMapInternalWork {
	public static void main(String[] args) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("1", "Manish");
		System.out.println("Done");
	}
}
