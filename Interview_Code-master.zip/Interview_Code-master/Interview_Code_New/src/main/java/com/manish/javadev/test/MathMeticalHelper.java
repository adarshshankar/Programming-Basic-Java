package com.manish.javadev.test;

/**
 * Hello world!
 *
 */
public class MathMeticalHelper {
	public int addNumber(int a, int b) {
		int c = a + b;
		return c;
	}

	public int divideNumber(int a, int b) {
		int c = a / b;
		return c;
	}
}
