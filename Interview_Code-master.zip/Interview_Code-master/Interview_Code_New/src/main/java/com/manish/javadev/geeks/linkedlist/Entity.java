package com.manish.javadev.geeks.linkedlist;

public class Entity {
	public int data;
	public Entity next;

	public Entity() {
	}

	public Entity(int data) {
		this.data = data;
	}

}
