package com.manish.javadev.tree;

public class BSTNode {
	int data;
	BSTNode left;
	BSTNode right;

	public BSTNode() {

	}

	public BSTNode(int data) {
		this.data = data;
	}

}
