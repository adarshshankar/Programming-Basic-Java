package com.manish.javadev.exception;

public interface Super {

	public void test1() throws Exception;

	public void test2();
}
